USERS = [
    {"login":"admin","password":"123","role":"Администратор"},
    {"login":"user","password":"123","role":"Администратор"},
]
